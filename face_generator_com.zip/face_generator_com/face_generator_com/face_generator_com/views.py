"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template,url_for    #导入模板库
import sys
sys.path[0]=r"C:\Users\Administrator\Desktop\face_generator_com\face_generator_com"
from face_generator_com import app,generate #从face_generator_com导入app函数
#定义路由和视图函数
#Flask中定义路由是由装饰器来实现的
#主视图,通过methods来决定可以接受什么请求，此处接受GET和POST请求
@app.route('/',methods=['GET','POST'])
#主页视图
@app.route('/home',methods=['GET','POST'])
#定义的路由和紧跟着定义的函数是一对的，通过访问路由，来找到这个函数，然后通过函数返回所需要的数据
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year
    )

@app.route('/dcgan',methods=['GET','POST'])#dcgan视图
def dcgan():
    path=url_for('static',filename='//face_image//dcgan_fake.jpg')
    flag1=generate.load_dcmodels() 
    flag2=generate.dcgenerate()
    """Renders the dcgan page."""
    return render_template(
        'dcgan.html',
        title='DCGAN',
        year=datetime.now().year,
        message='This page is to generate a face image via DCGAN.',
        models_load_flag=flag1,
        model_flag=flag2,
        imgpath=path
    )

@app.route('/began',methods=['GET','POST'])#dcgan视图
def began():
    path=url_for('static',filename='//face_image//began_fake.jpg')
    flag1=generate.load_bemodels() 
    flag2=generate.begenerate()
    """Renders the began page."""
    return render_template(
        'began.html',
        title='BEGAN',
        year=datetime.now().year,
        message='This page is to generate a face image via BEGAN.',
        models_load_flag=flag1,
        model_flag=flag2,
        imgpath=path
        
    )

@app.route('/about',methods=['GET','POST'])#关于视图函数，里面放了网站所有者的个人信息
def about():
    """Renders the about page."""
    return render_template(
        'about.html',
        title='About',
        year=datetime.now().year,
        message='此页是一些网站拥有者的个人信息：'
    )
