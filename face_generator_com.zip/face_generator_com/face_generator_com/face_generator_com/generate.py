# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import sys
import io
sys.path[0]=r"C:\Users\Administrator\Desktop\face_generator_com\face_generator_com\face_generator_com"
import models 
import dcgan
import torch
import cv2
from torch import nn
import matplotlib.pyplot as plt
import torchvision
import numpy as np
from PIL import Image
import torchvision.utils as vutils
import base64
sizebegan=64
sizedcgan=100
nc=3
nz=64
ngf=64
ngpu=1

def load_bemodels():
    global netbeGan
    try:
        netbeGan=models.Generator(nc,ngf,nz,sizebegan)
        netbegan_path=r"C:\Users\Administrator\Desktop\face_generator_com\face_generator_com\face_generator_com\netG_30000.pth"
        netbeGan.load_state_dict(torch.load(netbegan_path,map_location=torch.device('cpu')))
    except:
        return "model load failed"
    return "model load successfully"
def load_dcmodels():
    global netdcGan
    try:
        netdcGan=dcgan.Generator(ngpu)
        netdcgan_path=r"C:\Users\Administrator\Desktop\face_generator_com\face_generator_com\face_generator_com\netG_epoch_24.pth"
        netdcGan.load_state_dict(torch.load(netdcgan_path,map_location=torch.device('cpu')))
    except:
        return "model load failed"
    return "model load successfully"

def dcgenerate():
    noisedg=torch.randn(1,sizedcgan,1,1)
    dcgan_img=netdcGan(noisedg).detach().squeeze()
    try: 
        vutils.save_image(dcgan_img,"C:\\Users\\Administrator\\Desktop\\face_generator_com\\face_generator_com\\face_generator_com\\static\\face_image\\dcgan_fake.jpg",normalize=True)
        return "image generated is successfully"
    except Exception as e:
        return str(e)
def begenerate():
    noisebg=torch.randn(1,sizebegan)
    began_img=netbeGan(noisebg).detach().squeeze()
    try: 
        vutils.save_image(began_img,"C:\\Users\\Administrator\\Desktop\\face_generator_com\\face_generator_com\\face_generator_com\\static\\face_image\\began_fake.jpg",normalize=True)
        return "image generated is successfully"
    except Exception as e:
        return str(e)