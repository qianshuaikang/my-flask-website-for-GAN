"""
The flask application package.
"""
#从flask库导入Flask模块
from flask import Flask
from datatime import timedelta
#创建Flask程序实例，传入__name__，是为了确定资源所在的路径
app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT']=timedelta(seconds=5)
import sys
sys.path[0]=r"C:\Users\Administrator\Desktop\face_generator_com\face_generator_com"
import face_generator_com.views#导入视图函数
import face_generator_com.generate
import face_generator_com.models
import face_generator_com.dcgan
