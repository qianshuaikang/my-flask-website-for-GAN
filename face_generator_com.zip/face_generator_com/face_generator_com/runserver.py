"""
This script runs the face_generator_com application using a development server.
"""
import sys
from os import environ
sys.path[0]=r"C:\Users\Administrator\Desktop\face_generator_com\face_generator_com\face_generator_com"
from face_generator_com import app

#启动Python-WEB-Flask程序

if __name__ == '__main__':
    
    HOST = environ.get('SERVER_HOST', 'localhost')
    try:
        PORT = int(environ.get('SERVER_PORT', '5555'))
    except ValueError:
        PORT = 5555
    #执行了run（）函数，就能在服务器上执行程序
    
    app.run(HOST, PORT)
